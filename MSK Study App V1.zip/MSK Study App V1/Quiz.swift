//
//  protocol.swift
//  MSK Study App V2
//
//  Created by Trevor Khanna on 9/11/25.
//


import SwiftUI
import Foundation

// MARK: - QuizItem protocol
protocol QuizItem: Identifiable {
    var id: UUID { get }
    var name: String { get }
    var categories: [String: String] { get }
}

// MARK: - Quiz types
enum QuizType {
    case muscle
    case neuron
    case movement
}

// MARK: - GenericQuizItem
struct GenericQuizItem: QuizItem {
    let id = UUID()
    var name: String
    var categories: [String: String]
}

// MARK: - Study filters
struct StudyFilters {
    var regions: Set<String> = []
    var joints: Set<String> = []
    var movements: Set<String> = []

    var isEmpty: Bool { regions.isEmpty && joints.isEmpty && movements.isEmpty }

    func matches(_ item: GenericQuizItem) -> Bool {
        func values(_ key: String) -> Set<String> {
            Set((item.categories[key] ?? "").split(separator: ",").map { String($0).trimmingCharacters(in: .whitespaces) })
        }
        return (regions.isEmpty || !regions.isDisjoint(with: values("region"))) &&
               (joints.isEmpty || !joints.isDisjoint(with: values("joint"))) &&
               (movements.isEmpty || !movements.isDisjoint(with: values("action")))
    }
}

// MARK: - QuizManager
class QuizManager<T: QuizItem>: ObservableObject {
    @Published private(set) var items: [T] = []
    @Published private(set) var remainingItems: [T] = []
    @Published private(set) var askedItems: [T] = []
    @Published var currentItem: T? = nil
    @Published var quizOver = false
    @Published var userAnswers: [UUID: String] = [:]

    private var quizCategory: String
    private var quizType: QuizType

    init(type: QuizType, selectedCategory: String, questionLimit: Int, filters: StudyFilters = StudyFilters()) {
        
        let loadedItems = QuizManager.loadItems(for: type) as! [T]

        // Filter questions using the existing study filters
        let filteredItems = loadedItems.filter {
            filters.matches($0 as! GenericQuizItem) &&
            $0.categories[selectedCategory] != nil
        }

        // NEW: Track questions already included
        var seenQuestions = Set<String>()

        // NEW: Remove duplicate question-and-answer pairs
        let uniqueItems = filteredItems.filter { item in
            let question = item.name
                .trimmingCharacters(in: .whitespacesAndNewlines)
                .lowercased()

            let answer = (item.categories[selectedCategory] ?? "")
                .trimmingCharacters(in: .whitespacesAndNewlines)
                .lowercased()

            let key = "\(question)|\(answer)"

            return seenQuestions.insert(key).inserted
        }

        // Shuffle the unique questions
        let shuffledItems = uniqueItems.shuffled()

        // Apply the selected question limit
        let limitedItems = Array(
            shuffledItems.prefix(min(questionLimit, shuffledItems.count))
        )


        self.items = limitedItems
        self.remainingItems = limitedItems
        self.quizCategory = selectedCategory
        self.quizType = type
        self.nextItem()
    }

    func currentCategory() -> String {
        return quizCategory
    }

    func options(for category: String) -> [String] {
        guard let current = currentItem,
              let correct = current.categories[category] else { return [] }

        var options = Set<String>()
        options.insert(correct)

        let otherOptions = Set((Self.loadItems(for: quizType) as! [T]).compactMap { $0.categories[category] }).subtracting([correct])
        let randomOptions = Array(otherOptions.shuffled().prefix(3))
        randomOptions.forEach { options.insert($0) }

        return Array(options).shuffled()
    }

    func submitAnswer(_ answer: String) {
        guard !quizOver, let current = currentItem else { return }
        guard userAnswers[current.id] == nil else { return }
        userAnswers[current.id] = answer
        nextItem()
    }

    func nextItem() {
        if remainingItems.isEmpty {
            quizOver = true
            currentItem = nil
        } else {
            let next = remainingItems.removeFirst()
            currentItem = next
            askedItems.append(next)
        }
    }

    func endQuizEarly() {
        // Prevent any more questions from appearing
        remainingItems = []

        // Clear the current question
        currentItem = nil

        // Trigger the existing ResultsView
        quizOver = true
    }
    
    func resetQuiz() {
        remainingItems = items.shuffled()
        askedItems = []
        quizOver = false
        userAnswers = [:]
        nextItem()
    }

    static func loadItems(for type: QuizType) -> [any QuizItem] {
        let fileName: String
        switch type {
        case .muscle:   fileName = "MuscleInfo"
        case .neuron:   fileName = "NeuronInfo"
        case .movement: fileName = "MovementInfo"
        }

        guard let fileURL = Bundle.main.url(forResource: fileName, withExtension: "txt") else {
            print("\(fileName) file not found")
            return []
        }

        do {
            let contents = try String(contentsOf: fileURL, encoding: .utf8)

            return contents
                .split(separator: "\n")
                .compactMap { line in
                    // Split by commas and trim
                    let parts = line.split(separator: ";").map { $0.trimmingCharacters(in: .whitespaces) }
                    guard parts.count >= 2 else { return nil }

                    let name = parts[0]
                    let description = parts[1]

                    // Parse remaining key:value pairs (movement, neuron, etc.)
                    var categories: [String: String] = ["description": description]
                    for extra in parts.dropFirst(2) {
                        let kv = extra.split(separator: ":", maxSplits: 1)
                                      .map { $0.trimmingCharacters(in: .whitespaces) }
                        if kv.count == 2 {
                            categories[kv[0].lowercased()] = kv[1]
                        }
                    }

                    return GenericQuizItem(name: String(name), categories: categories)
                }

        } catch {
            print("Error reading \(fileName) file: \(error)")
            return []
        }
    }

}
