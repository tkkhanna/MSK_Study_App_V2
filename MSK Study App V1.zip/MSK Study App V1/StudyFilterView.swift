import SwiftUI

struct StudyFilterView: View {
    let quizType: QuizType
    let customMode: Bool
    @Binding var filters: StudyFilters
    let onContinue: () -> Void
    let onBack: () -> Void

    private let regions = ["Upper Body", "Lower Body", "Core / Back"]
    private let joints = ["Shoulder", "Scapula", "Elbow", "Wrist", "Hand", "Hip", "Knee", "Ankle", "Foot", "Spine / Neck"]
    private let movements = ["Flexion", "Extension", "Abduction", "Adduction", "Rotation", "Elevation", "Depression", "Other"]

    private var matchingCount: Int {
        (QuizManager<GenericQuizItem>.loadItems(for: quizType) as! [GenericQuizItem])
            .filter { filters.matches($0) && $0.categories[quizType == .muscle ? "neuron" : "muscle"] != nil }.count
    }
    
    private func isOptionAvailable(
        _ option: String,
        in group: String
    ) -> Bool {
        var testFilters = filters
        switch group {
        case "Body Region":
            testFilters.regions.insert(option)
        case "Joint / Area":
            testFilters.joints.insert(option)
        case "Movement":
            testFilters.movements.insert(option)
        default:
            return true
        }
        let items = QuizManager<GenericQuizItem>.loadItems(for: quizType)
            as! [GenericQuizItem]
        return items.contains { item in
            testFilters.matches(item) &&
            item.categories[quizType == .muscle ? "neuron" : "muscle"] != nil
        }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text(customMode ? "Custom Study" : "Quick Study")
                    .font(.largeTitle).bold().foregroundStyle(.primary)
                Text(customMode ? "Choose any combination. Multiple choices within a group include all of the selected options. Multiple choices across groups include only topics that fulfill all of the selected options. To choose all, do not select any options." : "Choose a region, or leave all unselected to study everything.")
                    .foregroundStyle(.secondary)
                section("Body Region", options: regions, selection: $filters.regions)
                if customMode {
                    section("Joint / Area", options: joints, selection: $filters.joints)
                    section("Movement", options: movements, selection: $filters.movements)
                }
                Text("\(matchingCount) matching study entries")
                    .font(.headline)
                    .foregroundColor(matchingCount == 0 ? .orange : .green)
                if matchingCount == 0 {
                    Text("No matching entries. Remove one or more filters to continue.")
                        .foregroundColor(.orange)
                }
                Button("Continue to Question Type") { onContinue() }
                    .buttonStyle(CustomButtonStyle(color: .blue))
                    .disabled(matchingCount == 0)
                    .opacity(matchingCount == 0 ? 0.5 : 1)
                Button("Back") { onBack() }
                    .buttonStyle(CustomButtonStyle(color: .gray))
            }
            .padding(24)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .background {Color(nsColor: .windowBackgroundColor).ignoresSafeArea()}
    }

    private func section(_ title: String, options: [String], selection: Binding<Set<String>>) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(title).font(.headline).foregroundStyle(.primary)
                Spacer()
                Button("Clear") { selection.wrappedValue = [] }
                    .foregroundColor(.accentColor)
            }
            ForEach(options, id: \.self) { option in
                let selected = selection.wrappedValue.contains(option)
                let available = !customMode || isOptionAvailable(option, in: title)
                Button {
                    if selected {
                        selection.wrappedValue.remove(option)
                    } else {
                        if !customMode {
                            selection.wrappedValue = []
                        }
                        selection.wrappedValue.insert(option)
                    }
                } label: {
                    HStack {
                        Image(systemName: selected ? "checkmark.square.fill" : "square")
                        Text(option)
                        Spacer()
                    }
                    .foregroundStyle(.primary)
                    .padding(10)
                    .background(Color.primary.opacity(0.08))
                    .cornerRadius(8)
                }
                .buttonStyle(.plain)
                .disabled(!available && !selected)
                .opacity(available || selected ? 1.0 : 0.3)
            }
        }
    }
}
